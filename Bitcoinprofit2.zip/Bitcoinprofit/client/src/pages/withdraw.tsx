import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Lock, AlertTriangle, Building, CreditCard, Wallet, Smartphone, DollarSign } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const withdrawSchema = z.object({
  amount: z.string().refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Amount must be greater than 0"),
  method: z.string(),
  // Dynamic fields validation will be handled manually or with refinement if needed, 
  // but for now we'll collect them in specific fields and combine them
  bankName: z.string().optional(),
  accountNumber: z.string().optional(),
  routingNumber: z.string().optional(),
  paymentUsername: z.string().optional(),
  walletAddress: z.string().optional(),
}).refine((data) => {
  if (data.method === "bank") {
    return !!data.bankName && !!data.accountNumber && !!data.routingNumber;
  }
  if (["paypal", "venmo", "cashapp"].includes(data.method)) {
    return !!data.paymentUsername;
  }
  if (data.method === "crypto") {
    return !!data.walletAddress;
  }
  return true;
}, {
  message: "Please fill in all required payment details",
  path: ["method"], // Attach error to method for general display
});

export default function Withdraw() {
  const { withdraw, currentUser } = useStore();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const form = useForm<z.infer<typeof withdrawSchema>>({
    resolver: zodResolver(withdrawSchema),
    defaultValues: {
      method: "bank",
    }
  });

  const selectedMethod = form.watch("method");

  const onSubmit = async (data: z.infer<typeof withdrawSchema>) => {
    setIsLoading(true);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    let details = "";
    if (data.method === "bank") {
      details = `Bank: ${data.bankName}, Acct: ${data.accountNumber}, Routing: ${data.routingNumber}`;
    } else if (["paypal", "venmo", "cashapp"].includes(data.method)) {
      details = `Username/Email: ${data.paymentUsername}`;
    } else if (data.method === "crypto") {
      details = `Wallet: ${data.walletAddress}`;
    }

    const result = await withdraw(parseFloat(data.amount), data.method, details);
    
    if (result.success) {
      toast({ 
        title: "Withdrawal Requested", 
        description: result.message,
      });
      form.reset({ method: "bank" });
    } else {
      toast({ 
        title: "Withdrawal Failed", 
        description: result.message,
        variant: "destructive"
      });
    }
    
    setIsLoading(false);
  };

  if (currentUser?.isWithdrawalLocked) {
    return (
      <div className="max-w-xl mx-auto mt-10">
        <Alert variant="destructive" className="border-destructive/50 bg-destructive/10">
          <Lock className="h-4 w-4" />
          <AlertTitle>Account Locked</AlertTitle>
          <AlertDescription className="mt-2">
            Withdrawals are currently disabled for your account.
            <div className="mt-2 p-2 bg-black/20 rounded text-sm font-mono">
              Reason: {currentUser.withdrawalLockReason || "Security verification required"}
            </div>
            <div className="mt-4 text-sm">
              Please contact support@crypto-platform.com to resolve this issue.
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Withdraw Funds</h1>
        <p className="text-muted-foreground">Transfer funds to your external account.</p>
      </div>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Request Withdrawal</CardTitle>
          <CardDescription>
            Available Balance: <span className="font-bold text-primary">${currentUser?.balance.toFixed(2)}</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            <div className="space-y-3">
              <Label>Withdrawal Method</Label>
              <RadioGroup 
                defaultValue="bank" 
                onValueChange={(val) => form.setValue("method", val)}
                className="grid grid-cols-2 gap-4"
              >
                <div>
                  <RadioGroupItem value="bank" id="bank" className="peer sr-only" />
                  <Label
                    htmlFor="bank"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Building className="mb-3 h-6 w-6" />
                    Bank Transfer
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="paypal" id="paypal" className="peer sr-only" />
                  <Label
                    htmlFor="paypal"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <CreditCard className="mb-3 h-6 w-6" />
                    PayPal
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="venmo" id="venmo" className="peer sr-only" />
                  <Label
                    htmlFor="venmo"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <Smartphone className="mb-3 h-6 w-6" />
                    Venmo
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="cashapp" id="cashapp" className="peer sr-only" />
                  <Label
                    htmlFor="cashapp"
                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                  >
                    <DollarSign className="mb-3 h-6 w-6" />
                    Cash App
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4 p-4 rounded-lg bg-secondary/30 border border-white/10">
              {selectedMethod === "bank" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="bankName">Bank Name</Label>
                    <Input id="bankName" placeholder="e.g. Chase, Bank of America" {...form.register("bankName")} />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="accountNumber">Account Number</Label>
                      <Input id="accountNumber" placeholder="0000000000" {...form.register("accountNumber")} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="routingNumber">Routing Number</Label>
                      <Input id="routingNumber" placeholder="000000000" {...form.register("routingNumber")} />
                    </div>
                  </div>
                </>
              )}

              {["paypal", "venmo", "cashapp"].includes(selectedMethod) && (
                <div className="space-y-2">
                  <Label htmlFor="paymentUsername">
                    {selectedMethod === "paypal" ? "PayPal Email" : 
                     selectedMethod === "venmo" ? "Venmo Handle (@username)" : 
                     "Cash App Tag ($cashtag)"}
                  </Label>
                  <Input 
                    id="paymentUsername" 
                    placeholder={
                      selectedMethod === "paypal" ? "email@example.com" : 
                      selectedMethod === "venmo" ? "@username" : "$cashtag"
                    } 
                    {...form.register("paymentUsername")} 
                  />
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Withdrawal Amount ($)</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-muted-foreground">$</span>
                <Input 
                  id="amount" 
                  type="number" 
                  step="0.01"
                  className="pl-7 bg-background/50 border-white/10" 
                  placeholder="0.00"
                  {...form.register("amount")}
                />
              </div>
              {form.formState.errors.amount && (
                <span className="text-xs text-destructive">{form.formState.errors.amount.message}</span>
              )}
              <div className="flex justify-between text-xs text-muted-foreground mt-2">
                 <span className="flex items-center gap-1"><AlertTriangle className="h-3 w-3" /> Min: $5,000.00</span>
                 <span>Max: $1,000,000.00</span>
              </div>
            </div>

            {form.formState.errors.method && (
               <div className="text-sm text-destructive bg-destructive/10 p-2 rounded">
                 Please complete all payment details above.
               </div>
            )}

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Withdrawal Request
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
