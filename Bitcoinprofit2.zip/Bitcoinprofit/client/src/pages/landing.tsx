import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp, Shield, Zap } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navbar */}
      <nav className="p-6 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="text-2xl font-bold text-gradient flex items-center gap-2">
          <Zap className="h-6 w-6 text-primary" />
          CryptoPlatform
        </div>
        <div className="flex gap-4">
          <Link href="/auth">
            <Button variant="ghost" className="text-foreground hover:bg-white/10">Login</Button>
          </Link>
          <Link href="/auth?mode=register">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_30px_rgba(59,130,246,0.4)]">
              Get Started
            </Button>
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col justify-center items-center text-center px-4 relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[120px] -z-10" />
        
        <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6">
          The Future of <span className="text-gradient">Crypto Trading</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mb-10">
          Experience the next generation of digital asset management. 
          Secure, fast, and built for everyone. Get 5x bonus on your first deposit.
        </p>
        
        <div className="flex gap-4 flex-col sm:flex-row">
          <Link href="/auth?mode=register">
            <Button size="lg" className="h-14 px-8 text-lg rounded-full bg-primary hover:bg-primary/90 shadow-[0_0_30px_rgba(59,130,246,0.4)] transition-all hover:scale-105">
              Start Trading Now <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/auth">
            <Button size="lg" variant="outline" className="h-14 px-8 text-lg rounded-full border-white/20 hover:bg-white/5 backdrop-blur-sm">
              View Demo
            </Button>
          </Link>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-3 gap-8 mt-24 max-w-6xl w-full px-4">
          <div className="glass-card p-8 rounded-2xl text-left">
            <div className="h-12 w-12 rounded-lg bg-blue-500/20 flex items-center justify-center mb-6">
              <TrendingUp className="h-6 w-6 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold mb-2">5x Deposit Bonus</h3>
            <p className="text-muted-foreground">Maximize your trading potential with our industry-leading bonus structure on every deposit.</p>
          </div>
          <div className="glass-card p-8 rounded-2xl text-left">
            <div className="h-12 w-12 rounded-lg bg-purple-500/20 flex items-center justify-center mb-6">
              <Shield className="h-6 w-6 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold mb-2">Bank-Grade Security</h3>
            <p className="text-muted-foreground">Your assets are protected by state-of-the-art encryption and cold storage protocols.</p>
          </div>
          <div className="glass-card p-8 rounded-2xl text-left">
            <div className="h-12 w-12 rounded-lg bg-pink-500/20 flex items-center justify-center mb-6">
              <Zap className="h-6 w-6 text-pink-400" />
            </div>
            <h3 className="text-xl font-bold mb-2">Instant Transfers</h3>
            <p className="text-muted-foreground">Lightning fast deposits and withdrawals. No more waiting days for your money.</p>
          </div>
        </div>
      </div>
      
      <footer className="p-8 text-center text-muted-foreground text-sm border-t border-white/5 mt-12">
        © 2025 CryptoPlatform. All rights reserved.
      </footer>
    </div>
  );
}
