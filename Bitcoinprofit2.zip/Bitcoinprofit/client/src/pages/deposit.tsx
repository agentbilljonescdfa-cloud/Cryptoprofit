import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2, TrendingUp, Copy, Check, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const depositSchema = z.object({
  amount: z.string().refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, "Amount must be greater than 0"),
  currency: z.string(),
});

// Wallet addresses configuration
const WALLET_ADDRESSES = {
  BTC: "bc1pd3v3669c2mch2usgmd9s0a9md54g27qnj7f5yda6h0jw238jr4msr68ljf",
  ETH: "0x37e902e5199337CB4fCd27d0682f89Da20FC45A2",
  USDT: "Contact support for USDT address",
  USD: ""
};

export default function Deposit() {
  const { deposit } = useStore();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const form = useForm<z.infer<typeof depositSchema>>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      currency: "USD",
    }
  });

  const selectedCurrency = form.watch("currency");
  const isCrypto = ["BTC", "ETH", "USDT"].includes(selectedCurrency);
  const walletAddress = WALLET_ADDRESSES[selectedCurrency as keyof typeof WALLET_ADDRESSES];

  const onSubmit = async (data: z.infer<typeof depositSchema>) => {
    setIsLoading(true);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    await deposit(parseFloat(data.amount), data.currency);
    
    toast({ 
      title: "Deposit Submitted", 
      description: "Your deposit request has been submitted for approval. It will be credited once confirmed.",
    });
    
    form.reset();
    setIsLoading(false);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(walletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied!", description: "Wallet address copied to clipboard." });
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Deposit Funds</h1>
        <p className="text-muted-foreground">Add funds to your account securely.</p>
      </div>

      <Alert className="bg-primary/10 border-primary/20 text-primary">
        <TrendingUp className="h-4 w-4" />
        <AlertTitle>Special Offer Active!</AlertTitle>
        <AlertDescription>
          Get 5x bonus on all deposits today. Deposit $100, get $500!
        </AlertDescription>
      </Alert>

      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Make a Deposit</CardTitle>
          <CardDescription>Select your preferred currency and amount</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-2">
              <Label>Currency</Label>
              <Select 
                onValueChange={(val) => form.setValue("currency", val)} 
                defaultValue="USD"
              >
                <SelectTrigger className="bg-background/50 border-white/10">
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD - US Dollar</SelectItem>
                  <SelectItem value="BTC">BTC - Bitcoin</SelectItem>
                  <SelectItem value="ETH">ETH - Ethereum</SelectItem>
                  <SelectItem value="USDT">USDT - Tether</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {isCrypto && (
              <div className="p-4 rounded-lg bg-secondary/50 border border-white/10 space-y-4">
                <div className="flex items-start gap-3">
                  <Info className="h-5 w-5 text-primary mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    Please send the exact amount to the address below. Your deposit will be credited after 1 confirmation.
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-xs uppercase text-muted-foreground">
                    {selectedCurrency} Deposit Address
                  </Label>
                  <div className="flex gap-2">
                    <code className="flex-1 p-3 rounded bg-background border border-white/10 font-mono text-sm break-all">
                      {walletAddress}
                    </code>
                    {selectedCurrency !== "USDT" && (
                      <Button type="button" size="icon" variant="outline" onClick={copyToClipboard}>
                        {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="amount">Amount ({selectedCurrency})</Label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-muted-foreground">$</span>
                <Input 
                  id="amount" 
                  type="number" 
                  step="0.01"
                  className="pl-7 bg-background/50 border-white/10" 
                  placeholder="0.00"
                  {...form.register("amount")}
                />
              </div>
              {form.formState.errors.amount && (
                <span className="text-xs text-destructive">{form.formState.errors.amount.message}</span>
              )}
            </div>

            {/* Live Calculation Preview */}
            <div className="p-4 rounded-lg bg-white/5 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Deposit Amount:</span>
                <span>${form.watch("amount") || "0"}</span>
              </div>
              <div className="flex justify-between text-sm text-primary">
                <span>Bonus (4x):</span>
                <span>+${(parseFloat(form.watch("amount") || "0") * 4).toFixed(2)}</span>
              </div>
              <div className="border-t border-white/10 pt-2 flex justify-between font-bold">
                <span>Total to Receive:</span>
                <span>${(parseFloat(form.watch("amount") || "0") * 5).toFixed(2)}</span>
              </div>
            </div>

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground" disabled={isLoading}>
              {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {isCrypto ? "I Have Sent The Payment" : "Submit Deposit Request"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="justify-center text-xs text-muted-foreground">
          All deposits are subject to manual verification.
        </CardFooter>
      </Card>
    </div>
  );
}
