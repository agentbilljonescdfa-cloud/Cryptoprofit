import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { Search, Lock, Unlock, CheckCircle, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Admin() {
  const { users, transactions, toggleLock, updateBalance, approveDeposit, updateTransactionStatus } = useStore();
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();

  const filteredUsers = users.filter(u => 
    !u.isAdmin && (
      u.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const pendingDeposits = transactions.filter(t => t.type === 'deposit' && t.status === 'pending');

  const handleToggleLock = (userId: string, currentStatus: boolean) => {
    toggleLock(userId, currentStatus ? undefined : "Security Review");
    toast({
      title: currentStatus ? "Account Unlocked" : "Account Locked",
      description: `User ${userId} status updated.`
    });
  };

  const handleUpdateBalance = (userId: string, currentBalance: number) => {
    const newBalance = prompt("Enter new balance:", currentBalance.toString());
    if (newBalance !== null && !isNaN(parseFloat(newBalance))) {
      updateBalance(userId, parseFloat(newBalance));
      toast({ title: "Balance Updated" });
    }
  };

  const handleApproveDeposit = (txId: string) => {
    approveDeposit(txId);
    toast({ title: "Deposit Approved", description: "Funds have been credited to the user." });
  };

  const handleRejectDeposit = (txId: string) => {
    updateTransactionStatus(txId, 'failed');
    toast({ title: "Deposit Rejected", variant: "destructive" });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
        <p className="text-muted-foreground">Manage users and transactions.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length - 1}</div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Deposits</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">
              {pendingDeposits.length}
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Withdrawals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {transactions.filter(t => t.type === 'withdrawal' && t.status === 'pending').length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Deposits Section */}
      {pendingDeposits.length > 0 && (
        <Card className="glass-card border-orange-200 bg-orange-50/50">
          <CardHeader>
            <CardTitle className="text-orange-700">Pending Deposit Approvals</CardTitle>
            <CardDescription>Review and approve user deposits</CardDescription>
          </CardHeader>
          <CardContent>
             <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>User ID</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Currency</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingDeposits.map((tx) => (
                  <TableRow key={tx.id}>
                    <TableCell className="font-mono text-xs">{tx.userId.substring(0, 8)}...</TableCell>
                    <TableCell>${tx.amount.toFixed(2)}</TableCell>
                    <TableCell>{tx.currency}</TableCell>
                    <TableCell className="text-xs">{new Date(tx.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button size="sm" variant="default" className="bg-green-600 hover:bg-green-700" onClick={() => handleApproveDeposit(tx.id)}>
                        <CheckCircle className="h-4 w-4 mr-1" /> Approve
                      </Button>
                      <Button size="sm" variant="destructive" onClick={() => handleRejectDeposit(tx.id)}>
                        <XCircle className="h-4 w-4 mr-1" /> Reject
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>User Management</CardTitle>
              <CardDescription>View and manage registered users</CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search users..." 
                className="pl-8 bg-background/50 border-white/10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-white/10 hover:bg-white/5">
                <TableHead>User</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Deposited</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id} className="border-white/10 hover:bg-white/5">
                  <TableCell>
                    <div className="font-medium">{user.username}</div>
                    <div className="text-xs text-muted-foreground">{user.email}</div>
                  </TableCell>
                  <TableCell>${user.balance.toFixed(2)}</TableCell>
                  <TableCell>${user.totalDeposited.toFixed(2)}</TableCell>
                  <TableCell>
                    {user.isWithdrawalLocked ? (
                      <Badge variant="destructive" className="flex w-fit items-center gap-1">
                        <Lock className="h-3 w-3" /> Locked
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-green-500/10 text-green-500 hover:bg-green-500/20 flex w-fit items-center gap-1">
                        <Unlock className="h-3 w-3" /> Active
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleUpdateBalance(user.id, user.balance)}
                    >
                      Edit Balance
                    </Button>
                    <Button 
                      variant={user.isWithdrawalLocked ? "secondary" : "destructive"} 
                      size="sm"
                      onClick={() => handleToggleLock(user.id, user.isWithdrawalLocked)}
                    >
                      {user.isWithdrawalLocked ? "Unlock" : "Lock"}
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
