import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

const registerSchema = z.object({
  username: z.string().min(3),
  email: z.string().email(),
  password: z.string().min(6),
});

export default function Auth() {
  const [location, setLocation] = useLocation();
  const searchParams = new URLSearchParams(window.location.search);
  const defaultTab = searchParams.get("mode") === "register" ? "register" : "login";
  
  const { login, register } = useStore();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
  });

  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
  });

  const onLogin = async (data: z.infer<typeof loginSchema>) => {
    setIsLoading(true);
    try {
      const success = await login(data.email, data.password);
      if (success) {
        toast({ title: "Welcome back!", description: "Successfully logged in." });
        setLocation("/dashboard");
      } else {
        toast({ title: "Error", description: "Invalid credentials.", variant: "destructive" });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const onRegister = async (data: z.infer<typeof registerSchema>) => {
    setIsLoading(true);
    try {
      const success = await register(data.username, data.email, data.password);
      if (success) {
        toast({ title: "Account created!", description: "Welcome to CryptoPlatform." });
        setLocation("/dashboard");
      } else {
        toast({ title: "Error", description: "User already exists.", variant: "destructive" });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=2832&auto=format&fit=crop')] bg-cover bg-center opacity-20 pointer-events-none" />
      
      <Card className="w-full max-w-md glass-card relative z-10">
        <Tabs defaultValue={defaultTab} className="w-full">
          <CardHeader>
            <CardTitle className="text-2xl text-center">CryptoPlatform</CardTitle>
            <CardDescription className="text-center">
              Access your digital assets securely
            </CardDescription>
            <TabsList className="grid w-full grid-cols-2 mt-4 bg-background/50">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>
          </CardHeader>
          
          <CardContent>
            <TabsContent value="login">
              <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" {...loginForm.register("email")} className="bg-background/50 border-white/10" />
                  {loginForm.formState.errors.email && (
                    <span className="text-xs text-destructive">{loginForm.formState.errors.email.message}</span>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input id="password" type="password" {...loginForm.register("password")} className="bg-background/50 border-white/10" />
                  {loginForm.formState.errors.password && (
                    <span className="text-xs text-destructive">{loginForm.formState.errors.password.message}</span>
                  )}
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Login
                </Button>
              </form>
            </TabsContent>
            
            <TabsContent value="register">
              <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input id="username" {...registerForm.register("username")} className="bg-background/50 border-white/10" />
                  {registerForm.formState.errors.username && (
                    <span className="text-xs text-destructive">{registerForm.formState.errors.username.message}</span>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-email">Email</Label>
                  <Input id="reg-email" type="email" {...registerForm.register("email")} className="bg-background/50 border-white/10" />
                  {registerForm.formState.errors.email && (
                    <span className="text-xs text-destructive">{registerForm.formState.errors.email.message}</span>
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="reg-password">Password</Label>
                  <Input id="reg-password" type="password" {...registerForm.register("password")} className="bg-background/50 border-white/10" />
                  {registerForm.formState.errors.password && (
                    <span className="text-xs text-destructive">{registerForm.formState.errors.password.message}</span>
                  )}
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create Account
                </Button>
              </form>
            </TabsContent>
          </CardContent>
          <CardFooter className="justify-center text-xs text-muted-foreground">
            By continuing, you agree to our Terms of Service
          </CardFooter>
        </Tabs>
      </Card>
    </div>
  );
}
