import { useStore } from "@/lib/store";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowDownLeft, ArrowUpRight, DollarSign, Wallet } from "lucide-react";
import { format } from "date-fns";

export default function Dashboard() {
  const { currentUser, transactions } = useStore();

  const userTransactions = transactions
    .filter(t => t.userId === currentUser?.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back, {currentUser?.username}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${currentUser?.balance.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Available for withdrawal</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deposited</CardTitle>
            <ArrowDownLeft className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${currentUser?.totalDeposited.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime deposits</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Withdrawn</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${currentUser?.totalWithdrawn.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime withdrawals</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Wallet Status</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentUser?.isWithdrawalLocked ? "Locked" : "Active"}</div>
            <p className="text-xs text-muted-foreground">
              {currentUser?.isWithdrawalLocked ? "Contact support" : "Fully operational"}
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold">Recent Transactions</h2>
        <Card className="glass-card">
          <CardContent className="p-0">
            {userTransactions.length === 0 ? (
              <div className="p-8 text-center text-muted-foreground">No transactions found</div>
            ) : (
              <div className="divide-y divide-white/10">
                {userTransactions.map((tx) => (
                  <div key={tx.id} className="p-4 flex items-center justify-between hover:bg-white/5 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        tx.type === 'deposit' ? 'bg-green-500/20 text-green-500' : 
                        tx.type === 'withdrawal' ? 'bg-red-500/20 text-red-500' : 
                        'bg-blue-500/20 text-blue-500'
                      }`}>
                        {tx.type === 'deposit' ? <ArrowDownLeft className="h-5 w-5" /> : <ArrowUpRight className="h-5 w-5" />}
                      </div>
                      <div>
                        <div className="font-medium capitalize">{tx.description || tx.type}</div>
                        <div className="text-xs text-muted-foreground">{format(new Date(tx.createdAt), 'PP p')}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`font-bold ${
                        tx.type === 'deposit' ? 'text-green-500' : 'text-red-500'
                      }`}>
                        {tx.type === 'deposit' ? '+' : '-'}${tx.total.toFixed(2)}
                      </div>
                      {tx.type === 'deposit' && tx.bonus > 0 && (
                        <div className="text-xs text-muted-foreground">
                          Deposited: ${tx.amount.toFixed(2)} + Bonus: ${tx.bonus.toFixed(2)}
                        </div>
                      )}
                      <div className="text-xs uppercase px-2 py-0.5 rounded-full bg-white/10 inline-block mt-1">
                        {tx.status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
