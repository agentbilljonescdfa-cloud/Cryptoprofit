import { Switch, Route, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { useEffect } from "react";
import Landing from "@/pages/landing";
import Auth from "@/pages/auth";
import Dashboard from "@/pages/dashboard";
import Deposit from "@/pages/deposit";
import Withdraw from "@/pages/withdraw";
import Admin from "@/pages/admin";
import Layout from "@/components/layout";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ component: Component, adminOnly = false }: { component: React.ComponentType, adminOnly?: boolean }) {
  const [location, setLocation] = useLocation();
  const { currentUser } = useStore();

  useEffect(() => {
    if (!currentUser) {
      setLocation("/auth");
    } else if (adminOnly && !currentUser.isAdmin) {
      setLocation("/dashboard");
    }
  }, [currentUser, adminOnly, setLocation]);

  if (!currentUser) return null;
  if (adminOnly && !currentUser.isAdmin) return null;

  return (
    <Layout>
      <Component />
    </Layout>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Landing} />
      <Route path="/auth" component={Auth} />
      
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      
      <Route path="/deposit">
        <ProtectedRoute component={Deposit} />
      </Route>
      
      <Route path="/withdraw">
        <ProtectedRoute component={Withdraw} />
      </Route>
      
      <Route path="/admin">
        <ProtectedRoute component={Admin} adminOnly />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

export default function App() {
  return (
    <>
      <Router />
      <Toaster />
    </>
  );
}
