import { Link, useLocation } from "wouter";
import { useStore } from "@/lib/store";
import { 
  LayoutDashboard, 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShieldCheck, 
  LogOut,
  Menu,
  X
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const { currentUser, logout } = useStore();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: ArrowDownLeft, label: "Deposit", href: "/deposit" },
    { icon: ArrowUpRight, label: "Withdraw", href: "/withdraw" },
    ...(currentUser?.isAdmin ? [{ icon: ShieldCheck, label: "Admin Panel", href: "/admin" }] : []),
  ];

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between p-4 glass sticky top-0 z-50">
        <div className="font-bold text-xl text-gradient">CryptoPlatform</div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="bg-background/95 backdrop-blur-xl border-r border-white/10 w-64 p-0">
            <div className="p-6">
              <div className="font-bold text-2xl text-gradient mb-8">CryptoPlatform</div>
              <nav className="flex flex-col gap-2">
                {navItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <a 
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 rounded-lg transition-all",
                        location === item.href 
                          ? "bg-primary/20 text-primary border border-primary/20" 
                          : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                      )}
                      onClick={() => setOpen(false)}
                    >
                      <item.icon className="h-5 w-5" />
                      {item.label}
                    </a>
                  </Link>
                ))}
                <button 
                  onClick={handleLogout}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all mt-4 w-full text-left"
                >
                  <LogOut className="h-5 w-5" />
                  Logout
                </button>
              </nav>
            </div>
          </SheetContent>
        </Sheet>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 glass-card m-4 rounded-2xl h-[calc(100vh-2rem)] sticky top-4">
        <div className="p-8">
          <div className="font-bold text-2xl text-gradient flex items-center gap-2">
            <Wallet className="h-8 w-8 text-primary" />
            <span>Crypto</span>
          </div>
        </div>
        
        <nav className="flex-1 px-4 flex flex-col gap-2">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <a 
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
                  location === item.href 
                    ? "bg-primary/20 text-primary border border-primary/20 shadow-[0_0_20px_rgba(59,130,246,0.15)]" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                <item.icon className="h-5 w-5" />
                {item.label}
              </a>
            </Link>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <div className="px-4 py-2 mb-4">
            <div className="text-xs text-muted-foreground mb-1">Logged in as</div>
            <div className="font-medium truncate">{currentUser?.username}</div>
            <div className="text-xs text-primary mt-1">{currentUser?.isAdmin ? 'Administrator' : 'User'}</div>
          </div>
          <Button 
            variant="ghost" 
            className="w-full justify-start gap-3 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto">
        <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
