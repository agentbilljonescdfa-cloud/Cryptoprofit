import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';

// Types based on your Mongoose Schemas
export type User = {
  id: string;
  username: string;
  email: string;
  password: string; // In a real app we'd hash this, but for mock we'll store as is
  balance: number;
  totalDeposited: number;
  totalWithdrawn: number;
  walletAddress: string;
  isAdmin: boolean;
  isWithdrawalLocked: boolean;
  withdrawalLockReason: string;
  createdAt: string;
};

export type Transaction = {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'bonus';
  amount: number;
  bonus: number;
  total: number;
  currency: 'BTC' | 'SOL' | 'USDT' | 'USD';
  status: 'pending' | 'completed' | 'failed' | 'cancelled';
  walletAddress: string;
  paymentMethod?: string;
  paymentDetails?: string;
  description: string;
  createdAt: string;
};

type StoreState = {
  currentUser: User | null;
  users: User[];
  transactions: Transaction[];
  
  // Actions
  login: (email: string, password: string) => Promise<boolean>;
  register: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  
  deposit: (amount: number, currency: string) => Promise<void>;
  withdraw: (amount: number, method: string, details: string) => Promise<{success: boolean, message: string}>;
  
  // Admin Actions
  toggleLock: (userId: string, reason?: string) => void;
  updateBalance: (userId: string, newBalance: number) => void;
  updateTransactionStatus: (txId: string, status: Transaction['status']) => void;
  approveDeposit: (txId: string) => void;
};

// Initial Admin User
const INITIAL_ADMIN: User = {
  id: 'admin-id',
  username: 'admin',
  email: 'admin@crypto.com',
  password: 'admin123',
  balance: 0,
  totalDeposited: 0,
  totalWithdrawn: 0,
  walletAddress: '0xAdminWallet',
  isAdmin: true,
  isWithdrawalLocked: false,
  withdrawalLockReason: '',
  createdAt: new Date().toISOString(),
};

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [INITIAL_ADMIN],
      transactions: [],

      login: async (email, password) => {
        const user = get().users.find(u => u.email === email && u.password === password);
        if (user) {
          set({ currentUser: user });
          return true;
        }
        return false;
      },

      register: async (username, email, password) => {
        const exists = get().users.some(u => u.email === email || u.username === username);
        if (exists) return false;

        const newUser: User = {
          id: nanoid(),
          username,
          email,
          password,
          balance: 500, // Initial bonus
          totalDeposited: 0,
          totalWithdrawn: 0,
          walletAddress: `0x${nanoid(20)}`,
          isAdmin: false,
          isWithdrawalLocked: false,
          withdrawalLockReason: '',
          createdAt: new Date().toISOString(),
        };

        set(state => ({
          users: [...state.users, newUser],
          currentUser: newUser
        }));
        return true;
      },

      logout: () => set({ currentUser: null }),

      deposit: async (amount, currency) => {
        const user = get().currentUser;
        if (!user) return;

        const bonusAmount = amount * 4;
        const totalAmount = amount * 5;
        
        // USD deposits are pending approval
        // Crypto deposits are also pending verification
        const status = 'pending';

        // Create transaction
        const tx: Transaction = {
          id: nanoid(),
          userId: user.id,
          type: 'deposit',
          amount: amount,
          bonus: bonusAmount,
          total: totalAmount,
          currency: currency as any,
          status: status,
          walletAddress: '',
          description: `Deposit Request - ${currency}`,
          createdAt: new Date().toISOString(),
        };

        // For pending deposits, we DO NOT update the user balance yet.
        // The admin must approve it first.

        set(state => ({
          transactions: [tx, ...state.transactions],
          // User balance is NOT updated here anymore
        }));
      },

      approveDeposit: (txId: string) => {
        const state = get();
        const tx = state.transactions.find(t => t.id === txId);
        if (!tx || tx.status !== 'pending' || tx.type !== 'deposit') return;

        const user = state.users.find(u => u.id === tx.userId);
        if (!user) return;

        // Apply balance and bonus on approval
        const updatedUser = {
          ...user,
          balance: user.balance + tx.total,
          totalDeposited: user.totalDeposited + tx.amount,
        };

        set(state => ({
          transactions: state.transactions.map(t => t.id === txId ? { ...t, status: 'completed' } : t),
          users: state.users.map(u => u.id === user.id ? updatedUser : u),
          currentUser: state.currentUser?.id === user.id ? updatedUser : state.currentUser
        }));
      },

      withdraw: async (amount, method, details) => {
        const user = get().currentUser;
        if (!user) return { success: false, message: 'Not authenticated' };

        if (user.isWithdrawalLocked) {
          return { success: false, message: user.withdrawalLockReason || 'Withdrawals are locked for this account.' };
        }

        if (amount < 5000) {
          return { success: false, message: 'Minimum withdrawal is $5,000' };
        }

        if (amount > 1000000) {
          return { success: false, message: 'Maximum withdrawal is $1,000,000' };
        }

        if (user.balance < amount) {
          return { success: false, message: 'Insufficient balance' };
        }

        // Process withdrawal
        const updatedUser = {
          ...user,
          balance: user.balance - amount,
          totalWithdrawn: user.totalWithdrawn + amount,
        };

        const tx: Transaction = {
          id: nanoid(),
          userId: user.id,
          type: 'withdrawal',
          amount: amount,
          bonus: 0,
          total: amount,
          currency: 'USD', // Defaulting to USD for these new methods
          status: 'pending',
          walletAddress: '', // Legacy field
          paymentMethod: method,
          paymentDetails: details,
          description: `Withdrawal request - ${method}`,
          createdAt: new Date().toISOString(),
        };

        set(state => ({
          transactions: [tx, ...state.transactions],
          currentUser: updatedUser,
          users: state.users.map(u => u.id === user.id ? updatedUser : u)
        }));

        return { success: true, message: 'Withdrawal request submitted' };
      },

      toggleLock: (userId, reason) => {
        set(state => ({
          users: state.users.map(u => {
            if (u.id === userId) {
              return { 
                ...u, 
                isWithdrawalLocked: !u.isWithdrawalLocked,
                withdrawalLockReason: reason || 'Contact support'
              };
            }
            return u;
          })
        }));
      },

      updateBalance: (userId, newBalance) => {
        set(state => ({
          users: state.users.map(u => u.id === userId ? { ...u, balance: newBalance } : u)
        }));
      },

      updateTransactionStatus: (txId, status) => {
        set(state => ({
          transactions: state.transactions.map(t => t.id === txId ? { ...t, status } : t)
        }));
      }
    }),
    {
      name: 'crypto-platform-storage',
    }
  )
);
